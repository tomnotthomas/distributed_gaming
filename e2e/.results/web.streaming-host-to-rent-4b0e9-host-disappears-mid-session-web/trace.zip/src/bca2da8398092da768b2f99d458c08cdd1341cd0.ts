// The whole product, end to end: a host starts sharing, a renter connects, and
// video actually arrives.
//
// Real signaling server, real production bundle, two real RTCPeerConnections
// negotiating over loopback. The single thing faked is the pixel source — a
// canvas stands in for the monitor, because a CI runner has no desktop worth
// capturing and `getDisplayMedia` would otherwise sit waiting for a human.
// Everything downstream of that track is the code that ships.

import { expect, test, type Page } from "@playwright/test";

/**
 * Replace `getDisplayMedia` with an animated canvas.
 *
 * Installed before any page script runs, so `Host` sees it as the real API.
 * The canvas is repainted on a timer because a still image encodes to almost
 * nothing and the renter's `videoWidth` can stay 0 — motion is what makes the
 * assertion below mean "frames are arriving".
 */
async function fakeScreenCapture(page: Page) {
  await page.addInitScript(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext("2d")!;

    let frame = 0;
    setInterval(() => {
      frame += 1;
      ctx.fillStyle = `hsl(${(frame * 9) % 360} 70% 45%)`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#fff";
      ctx.font = "96px sans-serif";
      ctx.fillText(String(frame), 60, 400);
    }, 60);

    const stream = (canvas as HTMLCanvasElement & {
      captureStream(fps?: number): MediaStream;
    }).captureStream(30);

    // Host applies width/frameRate constraints after the fact; a canvas track
    // rejects those, and the rejection would be reported as a capture failure.
    for (const track of stream.getVideoTracks()) {
      track.applyConstraints = async () => {};
    }

    navigator.mediaDevices.getDisplayMedia = async () => stream;
  });
}

/** Fail loudly on a page error rather than letting it surface as a timeout. */
function failOnPageError(page: Page, label: string) {
  const errors: string[] = [];
  page.on("pageerror", (err) => errors.push(`${label}: ${err.message}`));
  return errors;
}

test.describe("host to renter streaming", () => {
  test("carries the host's screen to the renter's video element", async ({ browser }) => {
    const hostCtx = await browser.newContext();
    const renterCtx = await browser.newContext();
    const host = await hostCtx.newPage();
    const renter = await renterCtx.newPage();

    const hostErrors = failOnPageError(host, "host");
    const renterErrors = failOnPageError(renter, "renter");

    await fakeScreenCapture(host);

    await host.goto("/host");
    await expect(host.getByRole("heading", { name: "Gaming PC" })).toBeVisible();
    await host.getByRole("button", { name: "Start sharing" }).click();

    // The host registers and then waits; nobody has joined yet.
    await expect(host.getByText("Waiting for a renter…")).toBeVisible();

    await renter.goto("/");
    await expect(renter.getByRole("heading", { name: "Swiff" })).toBeVisible();
    await renter.getByRole("button", { name: "Connect" }).click();

    // Each side learns about the other through the signaling server.
    await expect(host.getByText("A renter is connected.")).toBeVisible();

    // ICE completed and DTLS came up on both ends.
    await expect(renter.locator(".status")).toContainText("connected", { timeout: 30_000 });
    await expect(host.locator(".status")).toContainText("connected", { timeout: 30_000 });

    // And frames are genuinely decoding, not just a negotiated-but-silent track.
    await expect
      .poll(
        () => renter.locator("video.stream").evaluate((v: HTMLVideoElement) => v.videoWidth),
        { timeout: 30_000, message: "renter never received a decoded frame" },
      )
      .toBeGreaterThan(0);

    const playedSeconds = await renter
      .locator("video.stream")
      .evaluate((v: HTMLVideoElement) => v.currentTime);
    expect(playedSeconds, "video should be playing, not parked at 0").toBeGreaterThan(0);

    expect(hostErrors).toEqual([]);
    expect(renterErrors).toEqual([]);

    await hostCtx.close();
    await renterCtx.close();
  });

  test("reports which ICE path won, so a green light can be trusted", async ({ browser }) => {
    const hostCtx = await browser.newContext();
    const renterCtx = await browser.newContext();
    const host = await hostCtx.newPage();
    const renter = await renterCtx.newPage();

    await fakeScreenCapture(host);
    await host.goto("/host");
    await host.getByRole("button", { name: "Start sharing" }).click();
    await renter.goto("/");
    await renter.getByRole("button", { name: "Connect" }).click();

    await expect(renter.locator(".status")).toContainText("connected", { timeout: 30_000 });

    // Both peers are the same machine, so this is a loopback `host` pair. The
    // point of the assertion is that the status line resolves it at all rather
    // than sitting on "unknown" — that is what makes a real srflx/relay run
    // readable later.
    await expect(renter.locator(".status")).not.toContainText("unknown", { timeout: 20_000 });
    await expect(renter.locator(".status")).toContainText(/host|srflx|relay|prflx/);

    await hostCtx.close();
    await renterCtx.close();
  });

  test("tells the renter the gaming PC is offline when nothing is sharing", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Connect" }).click();

    await expect(page.getByText(/gaming PC is offline/)).toBeVisible();
  });

  test("tells the renter when the host disappears mid-session", async ({ browser }) => {
    const hostCtx = await browser.newContext();
    const renterCtx = await browser.newContext();
    const host = await hostCtx.newPage();
    const renter = await renterCtx.newPage();

    await fakeScreenCapture(host);
    await host.goto("/host");
    await host.getByRole("button", { name: "Start sharing" }).click();
    await renter.goto("/");
    await renter.getByRole("button", { name: "Connect" }).click();
    await expect(renter.locator(".status")).toContainText("connected", { timeout: 30_000 });

    // The gaming PC goes away without saying goodbye.
    await hostCtx.close();

    await expect(renter.getByText(/gaming PC disconnected/)).toBeVisible({ timeout: 20_000 });

    await renterCtx.close();
  });

  test("the host shows nothing is captured until sharing starts", async ({ page }) => {
    await fakeScreenCapture(page);
    await page.goto("/host");

    await expect(page.locator(".status")).toContainText("not capturing");
    await expect(page.getByRole("button", { name: "Start sharing" })).toBeVisible();
  });
});
